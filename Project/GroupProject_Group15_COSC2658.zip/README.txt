Member: 
Name: Dinh Pham | Student ID: S3878568
Name: Minh Vu   | Student ID: S3903723
Name: Jinho Ji  | Student ID: S3807487

Out last member is Son Cao, Student ID: S3916151. We sent him emails to invite him for group collaboration. However, he never responded to our emails. 
Therefore, our group is consisted of only 3 members. 

Contribution Score: 
Dinh Pham: 7
Minh Vu: 4
Jinho Ji: 4


Video Link: https://youtu.be/tnVvE8b9w5Q